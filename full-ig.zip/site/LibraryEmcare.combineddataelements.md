#### Inputs

required for the execution
| type | code / path | valueType | Description |
|---|---|---|---|
| Observation | EmCare.B11S1.DE01 | boolean/quantity | Diarrhoea |
| Observation | EmCare.B6.DE01A | CodeableConcept | Measured temperature |
| Observation | EmCare.B6.DE05 | boolean/quantity | Hot to Touch |
| Observation | EmCare.B12S1.DE02 | boolean/quantity | Fever Reported |
